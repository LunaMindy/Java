package ch05homeworkTest;

public class Test06 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
